function searchBooks() {
  const title = document.getElementById("title").value.toLowerCase();
  const author = document.getElementById("author").value.toLowerCase();
  const category = document.getElementById("category").value;

  const books = JSON.parse(localStorage.getItem("books")) || [];
  const loggedInUser = localStorage.getItem("loggedInUser");
  const borrowedBooks =
    JSON.parse(localStorage.getItem("borrowedBooks")) || {};
  const userBorrowedBooks = borrowedBooks[loggedInUser] || [];

  const results = books.filter((book) => {
    return (
      (!title || book.title.toLowerCase().includes(title)) &&
      (!author || book.author.toLowerCase().includes(author)) &&
      (!category || book.category === category)
    );
  });

  const searchResults = document.getElementById("searchResults");
  searchResults.innerHTML = "";

  results.forEach((book) => {
    const isBorrowed = userBorrowedBooks.some((b) => b.id === book.id);
    const bookCard = document.createElement("div");
    bookCard.className = "book-card";

    bookCard.innerHTML = `
                <div class="book-info">
                    <h3>${book.title}</h3>
                    <p><strong>Author:</strong> ${book.author}</p>
                    <p><strong>Category:</strong> ${book.category}</p>
                    <p>${book.description}</p>
                    <p class="${
                      isBorrowed ? "status-borrowed" : "status-in-stock"
                    }">
                        ${
                          isBorrowed
                            ? "Borrowed"
                            : book.inStock
                            ? "In Stock"
                            : "Out Of Stock"
                        }
                    </p>
                    ${
                      book.inStock && !isBorrowed
                        ? `<button class="borrow-btn" data-book-id="${book.id}">Borrow</button>`
                        : ""
                    }
                </div>
            `;

    if (book.inStock && !isBorrowed) {
      bookCard
        .querySelector(".borrow-btn")
        .addEventListener("click", function () {
          borrowBook(book);
        });
    }

    searchResults.appendChild(bookCard);
  });

  return false;
}

function borrowBook(book) {
  const loggedInUser = localStorage.getItem("loggedInUser");
  if (!loggedInUser) {
    alert("You must be logged in to borrow a book.");
    return;
  }

  const borrowedBooks =
    JSON.parse(localStorage.getItem("borrowedBooks")) || {};
  borrowedBooks[loggedInUser] = borrowedBooks[loggedInUser] || [];

  if (borrowedBooks[loggedInUser].some((b) => b.id === book.id)) {
    alert("You have already borrowed this book.");
    return;
  }

  borrowedBooks[loggedInUser].push(book);
  localStorage.setItem("borrowedBooks", JSON.stringify(borrowedBooks));

  const books = JSON.parse(localStorage.getItem("books")) || [];
  const bookIndex = books.findIndex((b) => b.id === book.id);
  if (bookIndex !== -1) {
    books[bookIndex].inStock = false;
    localStorage.setItem("books", JSON.stringify(books));
  }

  alert(`You have borrowed "${book.title}".`);
  searchBooks();
}