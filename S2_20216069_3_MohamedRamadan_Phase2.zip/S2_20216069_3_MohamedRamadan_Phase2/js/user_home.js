function displayBooks() {
    var books = JSON.parse(localStorage.getItem("books")) || [];

    var bookGrid = document.querySelector(".book-grid");
    bookGrid.innerHTML = "";
    books.forEach(function (book) {
        if (!book.id || !book.title || !book.author) return;
        var bookCard = document.createElement("div");
        bookCard.className = "book-card";
        var stockClass = book.inStock ? "status-in-stock" : "status-out-of-stock";
        var stockText = book.inStock ? "In Stock" : "Out Of Stock";
        bookCard.innerHTML = `
            <div class="book-info">
                <h3>${book.title}</h3>
                <p><strong>Author:</strong> ${book.author}</p>
                <p><strong>Category:</strong> ${book.category}</p>
                <p>${book.description}</p>
                <p class="${stockClass}">${stockText}</p>
                <div class="book-actions">
                    
                    ${book.inStock ? `<button class="borrow-btn">Borrow</button>` : ""}
                </div>
            </div>
        `;
        if (book.inStock) {
            bookCard.querySelector(".borrow-btn").addEventListener("click", function () {
                var loggedInUser = localStorage.getItem("loggedInUser");
                if (!loggedInUser) {
                    alert("You must be logged in to borrow a book.");
                    return;
                }
                var borrowedBooks = JSON.parse(localStorage.getItem("borrowedBooks")) || {};
                borrowedBooks[loggedInUser] = borrowedBooks[loggedInUser] || [];
                if (borrowedBooks[loggedInUser].some(b => b.id === book.id)) {
                    alert("You have already borrowed this book.");
                    return;
                }

                borrowedBooks[loggedInUser].push(book);
                localStorage.setItem("borrowedBooks", JSON.stringify(borrowedBooks));
                book.inStock = false;
                localStorage.setItem("books", JSON.stringify(books));

                alert(`You have borrowed "${book.title}".`);
                window.location.href = "borrowed_books.html";
            });
        }

        bookGrid.appendChild(bookCard);
    });
}

displayBooks();