function displayBooks() {
    var books = JSON.parse(localStorage.getItem("books")) || [];


    var bookGrid = document.querySelector(".book-grid");

    bookGrid.innerHTML = "";

    books.forEach(function (book) {
        var bookCard = document.createElement("div");
        bookCard.className = "book-card";

        bookCard.innerHTML = `
            <div class="book-info">
                <h3><strong>BookId:</strong> ${book.id}</h3>
                <h3>${book.title}</h3>
                <p><strong>Author:</strong> ${book.author}</p>
                <p><strong>Category:</strong> ${book.category}</p>
                <p>${book.description}</p>
                <p class="status-in-stock">${book.inStock ? "In Stock" : "Out Of Stock"}</p>
                <div class="book-actions">
                    <button class="view-details-btn" data-book-id="${book.id}">View Details</button>
                </div>
            </div>
        `;

        bookCard.querySelector(".view-details-btn").addEventListener("click", function () {
            window.location.href = `edit_book.html?id=${book.id}`;
        });

        bookGrid.appendChild(bookCard);
    });
}

function displayBorrowedBooksForAdmin() {

    var borrowedBooks = JSON.parse(localStorage.getItem("borrowedBooks")) || {};

    var bookGrid = document.querySelector(".book-grid");

    bookGrid.innerHTML = "";


    Object.keys(borrowedBooks).forEach(function (userEmail) {
        const displayedBookIds = new Set();

        borrowedBooks[userEmail].forEach(function (book) {
            if (!displayedBookIds.has(book.id)) {
                displayedBookIds.add(book.id);

                var bookCard = document.createElement("div");
                bookCard.className = "book-card";

                bookCard.innerHTML = `
                    <div class="book-info">
                        <h3><strong>BookId:</strong> ${book.id}</h3>
                        <h3>${book.title}</h3>
                        <p><strong>Author:</strong> ${book.author}</p>
                        <p><strong>Category:</strong> ${book.category}</p>
                        <p>${book.description}</p>
                        <p class="status-borrowed">Borrowed by: ${userEmail}</p>
                    </div>
                `;

                bookGrid.appendChild(bookCard);
            }
        });
    });
}
