
// z

function removeBook() {
    var bookID = document.getElementById("bookID").value;

    if (bookID == "") {
        alert("Please enter a Book ID.");
        return false;
    }

    var books = JSON.parse(localStorage.getItem("books")) || [];
    var borrowedBooks = JSON.parse(localStorage.getItem("borrowedBooks")) || {};
    var updatedBooks = books.filter(function (book) {
        return book.id !== bookID;
    });

    if (books.length === updatedBooks.length) {
        alert("Book not found in the main books list!");
        return false;
    }

    Object.keys(borrowedBooks).forEach(function (userEmail) {
        borrowedBooks[userEmail] = borrowedBooks[userEmail].filter(function (book) {
            return book.id !== bookID;
        });

        if (borrowedBooks[userEmail].length === 0) {
            delete borrowedBooks[userEmail];
        }
    });

    localStorage.setItem("books", JSON.stringify(updatedBooks));
    localStorage.setItem("borrowedBooks", JSON.stringify(borrowedBooks));

    alert("Book successfully removed from both the main list and borrowed books!");
    document.getElementById("removeBookForm").reset();

    return false;
}