document.addEventListener("DOMContentLoaded", function () {
  const bookId = new URLSearchParams(window.location.search).get("id");
  const books = JSON.parse(localStorage.getItem("books")) || [];
  const book = books.find((b) => b.id === bookId);

  if (book) {
    document.getElementById("dynamicBookDetails").innerHTML = `
      <h1>${book.title}</h1>
      <div class="book-details">
        <p><strong>Author:</strong> ${book.author}</p>
        <p><strong>Category:</strong> ${book.category}</p>
        <p>${book.description}</p>
      </div>
    `;
  } else {
    document.getElementById("dynamicBookDetails").innerHTML = `<p>Book not found.</p>`;
  }
});
