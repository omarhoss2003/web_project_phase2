document.addEventListener("DOMContentLoaded", function () {
  const urlParams = new URLSearchParams(window.location.search);
  const bookId = urlParams.get("id");

  if (bookId) {
    document.getElementById("searchBookID").value = bookId;
    searchBookById();
  }
});

function searchBookById() {
  const bookID = document.getElementById("searchBookID").value;
  const books = JSON.parse(localStorage.getItem("books")) || [];
  const book = books.find((b) => b.id === bookID);

  if (book) {
    document.getElementById("bookDetails").style.display = "block";
    document.getElementById("bookID").value = book.id;
    document.getElementById("title").value = book.title;
    document.getElementById("author").value = book.author;
    document.getElementById("category").value = book.category;
    document.getElementById("description").value = book.description;
  } else {
    alert("Book not found.");
    document.getElementById("bookDetails").style.display = "none";
  }
  return false;
}

function updateBookDetails() {
  const bookID = document.getElementById("bookID").value;
  const title = document.getElementById("title").value;
  const author = document.getElementById("author").value;
  const category = document.getElementById("category").value;
  const description = document.getElementById("description").value;

  let books = JSON.parse(localStorage.getItem("books")) || [];
  const bookIndex = books.findIndex((b) => b.id === bookID);

  if (bookIndex !== -1) {
    const inStock = books[bookIndex].inStock;


    books[bookIndex] = {
      id: bookID,
      title,
      author,
      category,
      description,
      inStock,
    };
    localStorage.setItem("books", JSON.stringify(books));

    let borrowedBooks =
      JSON.parse(localStorage.getItem("borrowedBooks")) || {};
    Object.keys(borrowedBooks).forEach((userEmail) => {
      borrowedBooks[userEmail] = borrowedBooks[userEmail].map((b) => {
        if (b.id === bookID) {
          return {
            ...b,
            title,
            author,
            category,
            description,
          };
        }
        return b;
      });
    });
    localStorage.setItem("borrowedBooks", JSON.stringify(borrowedBooks));

    alert("Book details updated successfully.");
  } else {
    alert("Book not found.");
  }
  return false;
}

function deleteBook() {
  const bookID = document.getElementById("bookID").value;

  let books = JSON.parse(localStorage.getItem("books")) || [];
  books = books.filter((b) => b.id !== bookID);
  localStorage.setItem("books", JSON.stringify(books));

  let borrowedBooks =
    JSON.parse(localStorage.getItem("borrowedBooks")) || {};
  Object.keys(borrowedBooks).forEach((userEmail) => {
    borrowedBooks[userEmail] = borrowedBooks[userEmail].filter(
      (b) => b.id !== bookID
    );
    if (borrowedBooks[userEmail].length === 0) {
      delete borrowedBooks[userEmail];
    }
  });
  localStorage.setItem("borrowedBooks", JSON.stringify(borrowedBooks));

  alert("Book deleted successfully.");
  document.getElementById("bookDetails").style.display = "none";
}
