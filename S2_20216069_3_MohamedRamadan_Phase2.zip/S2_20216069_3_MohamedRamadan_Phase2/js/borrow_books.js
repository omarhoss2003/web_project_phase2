
function displayBorrowedBooks() {
    var loggedInUser = localStorage.getItem("loggedInUser");
    if (!loggedInUser) {
        alert("You must be logged in to view borrowed books.");
        return;
    }
    var borrowedBooks = JSON.parse(localStorage.getItem("borrowedBooks")) || {};
    var userBorrowedBooks = borrowedBooks[loggedInUser] || [];
    var borrowedBooksGrid = document.querySelector(".book-grid");
    borrowedBooksGrid.innerHTML = "";


    const displayedBookIds = new Set();
    userBorrowedBooks.forEach(function (book) {
        if (!displayedBookIds.has(book.id)) {
            displayedBookIds.add(book.id);

            var bookCard = document.createElement("div");
            bookCard.className = "book-card";

            bookCard.innerHTML = `
                <div class="book-info">
                    <h3>${book.title}</h3>
                    <p><strong>Author:</strong> ${book.author}</p>
                    <p><strong>Category:</strong> ${book.category}</p>
                    <p>${book.description}</p>
                    <p class="status-borrowed">Borrowed</p>
                </div>
            `;

            borrowedBooksGrid.appendChild(bookCard);
        }
    });
}


displayBorrowedBooks();