// { id: "1", title: "The Great Gatsby", author: "F. Scott Fitzgerald", category: "Fiction", description: "A classic novel of the Jazz Age that explores themes of decadence, idealism, social upheaval, and excess.", inStock: true },
//{ id: "2", title: "1984", author: "George Orwell", category: "Fiction", description: "A dystopian novel set in a totalitarian society under constant surveillance.", inStock: true },
//{ id: "3", title: "To Kill a Mockingbird", author: "Harper Lee", category: "Fiction", description: "A story of racial injustice and moral growth in the Deep South.", inStock: false },
//{ id: "4", title: "The Catcher in the Rye", author: "J.D. Salinger", category: "Fiction", description: "A novel about teenage angst and alienation.", inStock: true },
//{ id: "5", title: "Lord of the Flies", author: "William Golding", category: "Fiction", description: "A story of savagery and the human condition.", inStock: false }




var books = [];

if (!localStorage.getItem("books")) {
    localStorage.setItem("books", JSON.stringify(books));
}

function addBook() {
    var bookID = document.getElementById("bookID").value;
    var title = document.getElementById("title").value;
    var author = document.getElementById("author").value;
    var category = document.getElementById("category").value;
    var description = document.getElementById("description").value;

    
    if (bookID == "") {
        alert("Please enter a Book ID.");
        return false;
    }
    if (title == "") {
        alert("Please enter a title.");
        return false;
    }
    if (author == "") {
        alert("Please enter an author.");
        return false;
    }
    if (category == "") {
        alert("Please select a category.");
        return false;
    }
    if (description == "") {
        alert("Please enter a description.");
        return false;
    }
    
    var storedBooks = JSON.parse(localStorage.getItem("books")) || [];

    if (storedBooks.some(book => book.id === bookID)) {
        alert("Book ID already exists.");
        return false;
    }

    
    var newBook = {
        id: bookID,
        title: title,
        author: author,
        category: category,
        description: description,
        inStock: true
    };
    storedBooks.push(newBook);
    localStorage.setItem("books", JSON.stringify(storedBooks));

    alert("Book successfully added!");
    document.getElementById("addBookForm").reset();
    displayBooks();

    return false;
}









