
// joe

var users = [];
var admins = [];
function signUp() {
    
    var email = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("confirm-password").value;
    var isAdmin = document.getElementById("is-admin").checked;

    
    if (email == "") {
        alert("Please enter an email.");
        return false;
    }
    if (password == "") {
        alert("Please enter a password.");
        return false;
    }
    if (password.length < 8) {
        alert("Password must be at least 8 characters long.");
        return false;
    }
    if (confirmPassword == "") {
        alert("Please confirm your password.");
        return false;
    }
    if (password != confirmPassword) {
        alert("Passwords do not match.");
        return false;
    }
    var storedUsers = JSON.parse(localStorage.getItem("users")) || [];
    var storedAdmins = JSON.parse(localStorage.getItem("admins")) || [];
    var emailExists = storedUsers.some(user => user.email === email) || 
                    storedAdmins.some(admin => admin.email === email);

    if (emailExists) {
        alert("This email is already registered. Please use a different email.");
        return false;
    }

    var user = {
        email: email,
        password: password,
        isAdmin: isAdmin
    };
    

    alert("Sign-up successful! Please log in.");

    
    if (isAdmin) {
        
        storedAdmins.push(user);
        localStorage.setItem("admins", JSON.stringify(storedAdmins));
        window.location.href = "admin_login.html";
    } else {
        
        storedUsers.push(user);
        localStorage.setItem("users", JSON.stringify(storedUsers));
        window.location.href = "user_login.html";
    }
    return false;
}



//user Login

function userLogin() {
    var email = document.getElementById("username").value;
    var password = document.getElementById("password").value;

    
    if (email == "") {
        alert("Please enter an email.");
        return false;
    }
    if (password == "") {
        alert("Please enter a password.");
        return false;
    }
    if (password.length < 8) {
        alert("Password must be at least 8 characters long.");
        return false;
    }

    var storedUsers = JSON.parse(localStorage.getItem("users")) || [];
    var found = false;
    for (var i = 0; i < storedUsers.length; i++) {
        if (storedUsers[i].email == email && storedUsers[i].password == password) {
            found = true;
            break;
        }
    }

    if (found) {
        localStorage.setItem("loggedInUser", email);

        window.location.href = "user_home.html";
    }
    return false;
}


//admin Login

function adminLogin() {
    localStorage.removeItem("loggedInUser");
    var email = document.getElementById("username").value;
    var password = document.getElementById("password").value;

    
    if (email == "") {
        alert("Please enter an email.");
        return false;
    }
    if (password == "") {
        alert("Please enter a password.");
        return false;
    }
    if (password.length < 8) {
        alert("Password must be at least 8 characters long.");
        return false;
    }

    var storedAdmins = JSON.parse(localStorage.getItem("admins")) || [];
    var found = false;
    for (var i = 0; i < storedAdmins.length; i++) {
        if (storedAdmins[i].email == email && storedAdmins[i].password == password ) {
            found = true;
            break;
        }
    }

    if (found == false) {
        alert("Invalid email or password, or you may be an admin.");
        return false;
    }

    
    window.location.href = "admin-home.html";
    return false;
}
